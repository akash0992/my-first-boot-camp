/**
 * Created by akash on 2/2/16.
 */



$(document).ready(function()
{
    var x = new Array(9);
    var i = 0;

    var p1 = 0, p2 = 1;

    var p1_name, p2_name;
    var p1_score=0,p2_score=0;

    var player_move = 0, td_val = 0;
    var move = 0;



    function update(){

            if(((x[0]==0)&&(x[1]==0)&&(x[2]==0))||((x[3]==0)&&(x[4]==0)&&(x[5]==0))||((x[6]==0)&&(x[7]==0)&&(x[8]==0))){

                alert(p1_name+" wins");
                p1_score=p1_score+10;
                $('.score1').html(p1_score);
                clear();
            }
            else if(((x[0]==0)&&(x[3]==0)&&(x[6]==0))||((x[1]==0)&&(x[4]==0)&&(x[7]==0))||((x[2]==0)&&(x[5]==0)&&(x[8]==0))){

                alert(p1_name+" wins");
                p1_score=p1_score+10;
                $('.score1').html(p1_score);
                clear();
            }
            else if(((x[0]==0)&&(x[4]==0)&&(x[8]==0))||((x[6]==0)&&(x[4]==0)&&(x[2]==0))){

                alert(p1_name+" wins");
                p1_score=p1_score+10;
                $('.score1').html(p1_score);
                clear();
            }
            else if(((x[0]==1)&&(x[1]==1)&&(x[2]==1))||((x[3]==1)&&(x[4]==1)&&(x[5]==1))||((x[6]==1)&&(x[7]==1)&&(x[8]==1))){

                alert(p2_name+" wins");
                p2_score=p2_score+10;
                $('.score2').html(p2_score);
                clear();
            }
            else if(((x[0]==1)&&(x[3]==1)&&(x[6]==1))||((x[1]==1)&&(x[4]==1)&&(x[7]==1))||((x[2]==1)&&(x[5]==1)&&(x[8]==1))){

                alert(p2_name+" wins");
                p2_score=p2_score+10;
                $('.score2').html(p2_score);
                clear();
            }
            else if(((x[0]==1)&&(x[4]==1)&&(x[8]==1))||((x[6]==1)&&(x[4]==1)&&(x[2]==1))){

                alert(p2_name+" wins");
                p2_score=p2_score+10;
                $('.score2').html(p2_score);
                clear();
            }
    }

    function reset(){

        for(i=0;i<9;i++)
        {
            x[i]=9;
        }
    }


    function clear(){

    $('td').each(function(){

        $(this).css({'background-image':'none'});
        move=0;
        player_move=0;
        if($(this).hasClass('fill_o')) {

            $(this).removeClass('fill_o');
        }
        else if($(this).hasClass('fill_x')) {

            $(this).removeClass('fill_x');
        }
        reset();
    });
        //on_css();
    }


    function result()
    {
        if(p1_score>p2_score){

            alert(p1_name+" wins the match by "+(p1_score-p2_score)+" points.");
        }
        else if(p1_score<p2_score){

            alert(p2_name+" wins the match by "+(p2_score-p1_score)+" points.");
        }
        else if(p1_score==p2_score) {

            alert("Oops Match is a Draw.");
        }
    }

    $('.display1').on('click', function () {

        $(this).css({'display': 'none'});

        do{
            p1_name = prompt("Enter your name (Player 1)");

        }while((p1_name == null) || (p1_name == "") || (!isNaN(p1_name)));

        do{
            p2_name = prompt("Enter your name (Player 2)");

        }while((p2_name == null) || (p2_name == "") || (!isNaN(p2_name)));

        $('.name1').html(p1_name);
        $('.name2').html(p2_name);
        $('.score1').html(p1_score);
        $('.score2').html(p2_score);
        $('.display2').css({'display': 'block'});
        $('.inner').css({'display': 'block'});
        clear();
    });


    $('.display2').on('click', function () {

        $(this).css({'display': 'none'});
        $('.inner').css({'display': 'none'});
        $('.display1').css({'display': 'block'});
        p1_score=0,p2_score=0;
    });


    $('.clear').on('click', function () {

        result();
    });


    $('.replay').on('click', function () {

        clear();
        reset();
    });


    $('td').on('click', function () {

           if (player_move == 0) {

               if($(this).hasClass('fill_o')) {

                   alert("Already marked !!! as 'O' ");
               }
               else if($(this).hasClass('fill_x')){

                 alert("Already marked !!! as 'X' ");
               }
               else{

                   $(this).css({'background-image': 'url(image/o.jpeg)'});
                   $(this).addClass('fill_o');
                   player_move = 1;
                   move++;
                   //alert(move);$(this).style.pointerEvents = 'none';
                   x[+$(this).attr("id")] = 0;
                   if (move >= 5) {
                       update();
                   }
                   // td_val = +$(this).attr("id");
                   // alert(td_val);
               }
           }
           else if (player_move == 1){

               if($(this).hasClass('fill_x')) {

                   alert("Already marked !!! as 'X' ");
               }
               else if($(this).hasClass('fill_o')){

                   alert("Already marked !!! as 'O' ");
               }
               else{

                   $(this).css({'background-image': 'url(image/x.jpeg)'});
                   $(this).addClass('fill_x');
                   player_move = 0;
                   move++;
                   //alert(move);
                   x[+$(this).attr("id")] = 1;
                   if (move >= 5) {
                       update();
                   }
                   // td_val = +$(this).attr("id");
                   // alert(td_val);
               }
           }
       });
});


