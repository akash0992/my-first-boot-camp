/**
 * Created by akash on 10/2/16.
 */

var userModel = require('../schema/user.model');

exports.find = function(query, callback){
    userModel.find(query, callback);
}