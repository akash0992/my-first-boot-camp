var express = require('express');
var router = express.Router();
var userService = require('../service/user.service');


/* GET users listing. */
router.get('/', function (req, res, next) {
    var query = req.query;
    userService.find(query, function (err, data) {
        if (err) {
            res.send('Error in getting users');
        } else {
                console.log(data);
            res.render('user/details', { title: 'Users',data:data});
        }
    });
});


router.post('/list', function (req, res, next) {
    var userObj = req.body;
    var uname = userObj.uname;
    var pass = userObj.password;
    //console.log(uname,pass);
    //var query = "{uname:{'$eq':"+uname+"},password:{'$eq':"+pass+"}}";
    userService.find({uname:uname, password:pass}, function (err, data) {
        if (err) {
            res.send('Error in getting users');
        } else {
            console.log('>>>>>>>>>>>>>>>>>',data);
            res.render('user/list', { title: 'User Detail',data:data});
        }
    });
});


router.get('/add', function (req, res, next) {

    res.render('user/add', { title: 'Add User'});
});

router.get('/edit/:id', function (req, res, next) {

    var id = req.params.id;
    userService.findById(id, function (err, data) {
        if (err) {
            res.redirect('/users');
            //res.send(res);
        } else {
            
            //res.send(data);
            res.render('user/edit', { title: 'Edit User', userData:data});
        }
    })

});

/* GET users listing. */
router.post('/add', function (req, res, next) {
    var userObj = req.body;
    userService.create(userObj, function (err, data) {
        if (err) {
            //res.send(err);
            res.redirect('/users/add');
        } else {
            //res.send(data);
            res.redirect('/users');
        }
    })
});


/* GET users listing. */
router.post('/edit/:id', function (req, res, next) {
    var id = req.params.id;
    var payload = req.body;
    userService.update(id, payload, function (err, data) {
        if (err) {
            res.redirect('/user/edit/'+id);
        } else {
            res.redirect('/users');
        }
    })
});


/* GET users listing. */
router.get('/delete/:id', function (req, res, next) {
    var id = req.params.id;
    userService.remove(id, function (err, data) {
        if (err) {
            //res.send('Error in removing users');
            res.redirect('/users');
        } else {
            res.redirect('/users');
        }
    })
});

module.exports = router;
