var express = require('express');
var router = express.Router();
var userService = require('../service/user.service');

/* GET home page. */
router.get('/', function(req, res, next) {
  var query = req.query;
  userService.find(query, function (err, data) {
    if (err) {
      res.send('Error in getting users');
    } else {
      //console.log(data);
      res.render('user/details', { title: 'Users List',data:data});
    }
  });

});

module.exports = router;

