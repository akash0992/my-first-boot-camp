var express = require('express');
var router = express.Router();


/* GET home page. */
router.get('/', function(req, res, next) {



		res.render('user/login', { title: 'Login'});

	
	//res.render('pages/login', { title: 'Express'});
});

module.exports = router;
