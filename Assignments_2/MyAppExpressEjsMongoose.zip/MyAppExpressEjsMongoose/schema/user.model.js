/**
 * Created by akash on 9/2/16.
 */

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var user  = new Schema({
    fname : {type:String, required:true},
    lname : {type:String},
    uname : {type:String, required:true, unique:true},
    email : {type:String, required:true, lowercase:true, unique:true},
    password : {type:String, required:true},
    //address : {
    //    address1:{type:String, required:true},
    //    address2:{type:String},
    //    country:{type:String, required:true},
    //    state:{type:String, required:true},
    //    city:{type:String, required:true},
    //    zip:{type:Number, required:true}
    //},
    phoneNumber:{type:String}
});

var userModel = mongoose.model('user',user);

module.exports=userModel;