/**
 * Created by akash on 9/2/16.
 */


var userModel = require('../schema/user.model');


exports.find=function(query,callback){
    //console.log('======', query)
    userModel.find(query,function(error,data){  //userModel.find(query,callback);
        callback(error,data);
    });
};

exports.findById = function (id, callback) {
    userModel.findById(id, function (err, data) {
        callback(err, data);
    });
};

exports.create=function(payload,callback){

    var userObj  = {
        fname : payload.fname,
        lname : payload.lname,
        uname : payload.uname,
        email : payload.email,
        password : payload.password,
        //address : {
        //    address1:payload.address.address1,
        //    address2:payload.address.address2,
        //    country:payload.address.country,
        //    state:payload.address.state,
        //    city:payload.address.city,
        //    zip:payload.address.zip
        //},
        phoneNumber:payload.phoneNumber
    };

    var newUser = new userModel(userObj);
    newUser.save(function(err,data){
        callback(err,data);
    });
};


exports.update = function(id,payload,callback){
    userModel.findById(id,function(error,data) {
        if(error){
            callback(error,null);
        }

        data.fname = payload.fname;
        data.lname = payload.lname;
        data.uname = payload.uname;
        data.email = payload.email;
        data.password = payload.password;
        //data.address1 = payload.address.address1;
        //data.address2 = payload.address.address2;
        //data.country = payload.address.country;
        //data.state = payload.address.state;
        //data.city = payload.address.city;
        //data.zip = payload.address.zip;
        data.phoneNumber = payload.phoneNumber;


        data.save(function(err,data){
            callback(err,data);
        });
    });
};

exports.remove = function(id,callback){
    userModel.findById(id,function(error,data) {
        if(error){
            callback(error,null);
        }
        data.remove(function(err,data){
            callback(err,data);
        });
    });
};